CP_Storage = {
}
DN_Options_Of_Char = {
	["Vidar"] = {
	},
}
QH_Priorities = {
}
WoWMap_LastMap = 14
g_NpcTrackTable = {
}
g_ShowCraftCautionAgain = true
gsqtVARS = {
	["pos_x"] = 200,
	["mode"] = "Donate",
	["pos_y"] = 200,
	["active"] = true,
}
nkChat_Settings = {
	["EditBoxChannelButton"] = false,
	["EditBoxYPOS"] = 300,
	["ShowButtonEmote"] = false,
	["MouseScrolling"] = true,
	["AlphaOnLeave"] = 1,
	["ShowSlider"] = true,
	["ChatBoxWidth"] = 550,
	["ChatBoxHeight"] = 182,
	["EditBoxAttachedTo"] = 1,
	["ShowTabs"] = true,
	["ChatBoxBGAlpha"] = 0.60000002384186,
	["ShowButtonRestore"] = false,
	["EditBoxXPOS"] = 300,
	["AlphaOnEnter"] = 1,
	["ChatBoxXPOS"] = 0,
	["ChatBoxTimestamp"] = false,
	["ShowSizer"] = false,
	["EditBoxWidth"] = 200,
	["ChatBoxYPOS"] = 571,
}
